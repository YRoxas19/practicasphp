<html>
<body>
<?php
class bombilla{
private $watios;
private $encendido;
public function inicializar($vat, $val)
{
$this->watios=$vat;
$this->encendido=$val;
}
public function enciende()
{ 
echo "<img id='imagen' src='on.gif'>";


}
public function apagar()
{ 
echo "<img id='imagen' src='off.gif'>";


}
}

?>
<form action="clases1.php" method="post">

<input type="submit" value="encender" name ="encender">
<input type="submit" value="apagar" name ="apagar">
</form>

<?php
if (isset($_POST["encender"]))
{ $bomba=new bombilla();
$bomba->inicializar(100,1);
$bomba->enciende();
}
else if(isset($_POST["apagar"]))
{ $bomba=new bombilla();
$bomba->inicializar(100,1);
$bomba->apagar();
}
?>
</body>
</html>